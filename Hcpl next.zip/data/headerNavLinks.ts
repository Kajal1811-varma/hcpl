const headerNavLinks = [
  { href: '/', title: 'Home' },
  { href: '/aboutus', title: 'About Us' },
  { href: '/board', title: 'Board' },
  { href: '/business', title: 'Business' },
  { href: '/impact', title: 'Impact' },
  { href: '/career', title: 'Career' },
  { href: '/contactus', title: ' Contact Us' },
]

export default headerNavLinks
